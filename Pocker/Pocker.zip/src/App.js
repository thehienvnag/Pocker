import React from 'react';
import Layout from './layouts';

function App() {
  return (
    <Layout></Layout>
  );
}

export default App;
